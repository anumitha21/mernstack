import React from 'react'
import { Container } from 'react-bootstrap'
import './Spinner.css'

const Spinner = () => {
  return (
    <Container className="mt-5" style={{ position: 'relative', zIndex: "2 !important", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div className="spinner-container">
        <div className="spinner"></div>
      </div>
    </Container>
  )
}

export default Spinner