// NavbarComponent.js
import React, { useEffect, useState } from 'react';
import { Navbar, Nav, Button, Container } from 'react-bootstrap';
import "./style.css";
import { useNavigate } from 'react-router-dom';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';

const Header = () => {
  const navigate = useNavigate();

  const handleShowLogin = () => {
    navigate("/login");
  }

  const [user, setUser] = useState();

  useEffect(() => {
    if (localStorage.getItem("user")) {
      const user = JSON.parse(localStorage.getItem("user"));
      setUser(user);
    }
  }, []);

  const handleShowLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  }

  return (
    <>
      <div style={{ position: 'relative', overflow: 'hidden' }}>
        <Navbar collapseOnSelect expand="lg" style={{ position: 'relative', zIndex: "2 !important", backgroundColor: 'white', padding: '15px 0', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
          <Container>
            <Navbar.Brand href="/home" style={{ color: "#007bff", fontWeight: "bold", fontSize: "20px", display: "flex", alignItems: "center" }}>
              <AccountBalanceWalletIcon sx={{ fontSize: 30, color: "#007bff", marginRight: "10px" }} />
              Expense Management System
            </Navbar.Brand>
            <Navbar.Toggle
              aria-controls="basic-navbar-nav"
              style={{
                backgroundColor: "transparent",
                borderColor: "#007bff",
              }}
            >
              <span
                className="navbar-toggler-icon"
                style={{
                  background: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='30' height='30' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 123, 255)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e")`,
                }}
              ></span>
            </Navbar.Toggle>
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="ms-auto" style={{ gap: "15px", alignItems: "center" }}>
                {user ? (
                  <>
                    <Nav.Link href="/home" style={{ color: "#007bff", fontWeight: "500" }}>Home</Nav.Link>
                    <Nav.Link href="/about" style={{ color: "#007bff", fontWeight: "500" }}>About</Nav.Link>
                    <Nav.Link href="/contact" style={{ color: "#007bff", fontWeight: "500" }}>Contact</Nav.Link>
                    <Button variant="outline-danger" onClick={handleShowLogout} size="sm">Logout</Button>
                  </>
                ) : (
                  <>
                    <Button variant="primary" onClick={handleShowLogin}>Login</Button>
                  </>
                )}
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </div>
    </>
  );
};

export default Header;
