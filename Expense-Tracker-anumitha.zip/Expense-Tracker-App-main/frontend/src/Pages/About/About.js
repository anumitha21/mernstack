import { Container, Row, Col, Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import "../Auth/auth.css";

const About = () => {
    return (
        <div style={{ position: "relative", overflow: "hidden", backgroundColor: '#87CEEB', minHeight: '100vh' }}>
            <Container className="mt-5" style={{ position: "relative", zIndex: "2 !important" }}>
                <Row>
                    <Col md={{ span: 8, offset: 2 }}>
                        <h1 className="text-center mt-5">
                            <AccountBalanceWalletIcon sx={{ fontSize: 40, color: "white" }} className="text-center" />
                        </h1>
                        <h2 className="text-white text-center">About Expense Management System</h2>

                        <Card className="mt-4" style={{ backgroundColor: "rgba(255, 255, 255, 0.9)" }}>
                            <Card.Body>
                                <h4>Project Overview</h4>
                                <p>
                                    The Expense Management System is a comprehensive web application designed to help users
                                    track and manage their personal finances efficiently. This application enables users to
                                    monitor their income and expenses, providing valuable insights into their spending habits.
                                </p>

                                <h4 className="mt-4">Key Features</h4>
                                <ul>
                                    <li>User authentication and secure login</li>
                                    <li>Add, edit, and delete transactions</li>
                                    <li>Track income and expenses</li>
                                    <li>View transaction history</li>
                                    <li>Categorize transactions</li>
                                    <li>Responsive design for all devices</li>
                                </ul>

                                <h4 className="mt-4">Technologies Used</h4>
                                <ul>
                                    <li><strong>Frontend:</strong> React.js, React Bootstrap, Material-UI Icons</li>
                                    <li><strong>Backend:</strong> Node.js, Express.js</li>
                                    <li><strong>Database:</strong> MongoDB</li>
                                    <li><strong>Authentication:</strong> JWT (JSON Web Tokens)</li>
                                </ul>

                                <h4 className="mt-4">Purpose</h4>
                                <p>
                                    This system aims to simplify financial management by providing an intuitive interface
                                    for tracking daily transactions. Users can gain better control over their finances and
                                    make informed decisions about their spending.
                                </p>
                            </Card.Body>
                        </Card>

                        <div className="text-center mt-4 mb-5">
                            <Link to="/login" className="text-white" style={{ textDecoration: "none", fontSize: "18px" }}>
                                ← Back to Login
                            </Link>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default About;
