import { Container, Row, Col, Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import "../Auth/auth.css";

const Contact = () => {
    return (
        <div style={{ position: "relative", overflow: "hidden", backgroundColor: '#87CEEB', minHeight: '100vh' }}>
            <Container className="mt-5" style={{ position: "relative", zIndex: "2 !important" }}>
                <Row>
                    <Col md={{ span: 8, offset: 2 }}>
                        <h1 className="text-center mt-5">
                            <AccountBalanceWalletIcon sx={{ fontSize: 40, color: "white" }} className="text-center" />
                        </h1>
                        <h2 className="text-white text-center">Contact Information</h2>

                        <Card className="mt-4" style={{ backgroundColor: "rgba(255, 255, 255, 0.9)" }}>
                            <Card.Body>
                                <h4 className="text-center mb-4">Get In Touch</h4>

                                <div className="text-center">
                                    <h5 className="mt-4">Developer Information</h5>
                                    <p className="mb-2"><strong>Name:</strong> Anumitha V</p>
                                    <p className="mb-2"><strong>Department:</strong> CSE A</p>
                                </div>

                                <hr className="my-4" />

                                <div className="text-center">
                                    <h5>About This Project</h5>
                                    <p>
                                        This Expense Management System is designed to help users track and manage
                                        their personal finances efficiently. Feel free to explore the features and
                                        reach out if you have any questions or feedback.
                                    </p>
                                </div>
                            </Card.Body>
                        </Card>

                        <div className="text-center mt-4 mb-5">
                            <Link to="/home" className="text-white" style={{ textDecoration: "none", fontSize: "18px", marginRight: "20px" }}>
                                ← Back to Home
                            </Link>
                            <Link to="/about" className="text-white" style={{ textDecoration: "none", fontSize: "18px" }}>
                                About Project →
                            </Link>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Contact;
